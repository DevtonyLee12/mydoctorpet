import 'dart:ffi';
import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:mypet_doctor/model/doctorprofile.dart';
import 'package:mypet_doctor/services/read_doctorname.dart';
import 'package:mypet_doctor/ui/doc_profile.dart';
import '../../services/doctor_service.dart';
import 'filter_head.dart';

class docList extends StatefulWidget {
  const docList({Key? key}) : super(key: key);

  @override
  State<docList> createState() => _docList();
}

// class _docList extends State<docList> {
//   final List<String> imageLIst = [
//     'https://www.snuh.org/upload/med/dr/79a699d52b604c18bdd50a34f5b76251.jpg',
//     'https://www.snuh.org/upload/med/dr/1026520_65318_01.jpg',
//     'https://www.snuh.org/upload/med/dr/1033710_01976_01.jpg',
//     'https://www.snuh.org/upload/med/dr/1034783_65621_01.jpg',
//     'https://www.snuh.org/upload/med/dr/a2df63833724497ab2465fd5ac7f553c.jpg',
//     'https://www.snuh.org/upload/med/dr/1014537_00787_01.jpg',
//     'https://www.snuh.org/upload/med/dr/76a20bbdbd354253819859c92b7d919c.jpg',
//     'https://www.snuh.org/upload/med/dr/85305dbad14f4b92a3c2df3ffe9438e2.jpg',
//     'https://www.snuh.org/upload/med/dr/a963697b325e477cb1d00771442bdcd3.jpg',
//     'https://www.snuh.org/upload/med/dr/b4ee6599263c4094b5e4a3f2e5a7a6b6.jpg',
//   ];
//   final List<String> names = [
//     '홍길동',
//     '김철수',
//     '이영수',
//     '유경회',
//     '차진우',
//     '황현태',
//     '신지선',
//     '윤희원',
//     '손재민',
//     '곽기섭',
//   ];
//   final List<String> hospitals = [
//     '강동 동물병원',
//     '강서 동물병원',
//     '강북 동물병원',
//     '동대문 동물병원',
//     '송파 동물병원',
//     '강동 동물병원',
//     '강남 동물병원',
//     '서초 동물병원',
//     '동작 동물병원',
//     '관악 동물병원',
//   ];

class _docList extends State<docList> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xff73e4fd),
        leading: IconButton(
          icon: Icon(CupertinoIcons.back, color: Color(0xff00a0c3)),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        centerTitle: true,
        title: Text("수의사 찾기",
            style: TextStyle(
              fontSize: 20,
              color: Colors.black,
            )),
      ),
      body: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(children: [
            Filter(),
            SizedBox(height: 10),
            FutureBuilder<List<DoctorProfile>>(
                future: DoctorProfileService().getDotors(),
                builder: (context, snapshot) {
                  if (snapshot.hasData)
                  // reviewList가 비어있으면,
                  {
                    List<DoctorProfile> doctorInformaion = snapshot.data!;

                    return Expanded(
                        child: ListView.builder(
                      itemCount: doctorInformaion.length,
                      itemBuilder: (context, index) {
                        DoctorProfile doctorinformaions =
                            doctorInformaion[index];

                        doctorinformaions.medicalSubject.contains('응급진료');

                        // final docs = documentforDoctor[index];

                        // String name = docs.get('name');
                        // String hospital = docs.get('hospital');
                        // String medicalSubject = docs.get('medicalSubject');

                        // FutureBuilder(
                        //     future: DoctorProfileService.getDoctorIDs(),
                        //     builder: (context, index) {
                        //       return ListView.builder(
                        //           itemCount: DoctorProfileService.doctorIDs.length,
                        //           itemBuilder: (context, index) {

                        return Container(
                          height: 70,
                          margin: const EdgeInsets.symmetric(
                              horizontal: 5, vertical: 15),
                          child: InkWell(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => DocProfileDetail(
                                        doctorInformations:
                                            doctorInformaion[index])),
                              );
                            }, //현재 리뷰 페이지로 되어 있지만, 의사 및 리뷰 페이지로 이동
                            child: Row(
                              children: [
                                Expanded(
                                    flex: 1,
                                    child: CircleAvatar(
                                        backgroundImage: NetworkImage(
                                          doctorinformaions.profileImage,
                                        ),
                                        radius: 40.0)),
                                SizedBox(
                                  width: 20,
                                ),
                                Expanded(
                                  flex: 3,
                                  child: Container(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Expanded(
                                            flex: 1,
                                            child: Row(children: [
                                              Text(
                                                doctorinformaions.name,
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Icon(
                                                CupertinoIcons.paw,
                                                size: 18,
                                                color: Colors.blue,
                                              ),
                                              SizedBox(width: 3),
                                              Text("5.0"),
                                              SizedBox(
                                                width: 3,
                                              ),
                                              Text(
                                                "(50)",
                                                style: TextStyle(fontSize: 12),
                                              ),
                                            ])),
                                        Expanded(
                                            flex: 1,
                                            child: Container(
                                              child: Row(children: [
                                                Text(
                                                    doctorinformaions.hospital),
                                                SizedBox(width: 15),
                                                Icon(
                                                  CupertinoIcons.star_fill,
                                                  size: 14,
                                                  color: Colors.green,
                                                ),
                                                SizedBox(width: 3),
                                                Text(doctorinformaions
                                                    .ratingInNaver
                                                    .toString()),
                                                SizedBox(
                                                  width: 3,
                                                ),
                                                Text(
                                                  "(50)",
                                                  style:
                                                      TextStyle(fontSize: 12),
                                                ),
                                                SizedBox(
                                                  width: 10,
                                                ),
                                              ]),
                                            )),
                                        Expanded(
                                            flex: 1,
                                            child: Container(
                                              child: Row(
                                                children: [
                                                  Container(
                                                    width: 60,
                                                    alignment: Alignment.center,
                                                    decoration: BoxDecoration(
                                                      color: Color(0xfff3f1de),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              30),
                                                    ),
                                                    child: Text(
                                                        doctorinformaions
                                                            .medicalSubject),
                                                  ),
                                                  SizedBox(width: 25),
                                                  doctorinformaions
                                                          .medicalSubject
                                                          .contains('응급진료')
                                                      //컨텐인 함수,, 문자열이 포함 되어 있으면
                                                      ? Container(
                                                          width: 90,
                                                          alignment:
                                                              Alignment.center,
                                                          decoration:
                                                              BoxDecoration(
                                                            color: Color(
                                                                0xffff8888),
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        30),
                                                          ),
                                                          child: Text(
                                                            "응급진료 가능",
                                                            style: TextStyle(
                                                                color: Colors
                                                                    .white),
                                                          ))
                                                      : Text("")
                                                ],
                                              ),
                                            )),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ));
                  }
                  return Text("리스트가 없습니다.");
                })
          ])),
      // floatingActionButton: FloatingActionButton(onPressed: () {
      //   print(DoctorProfileService().getDotors());
      // }
      // )
    );
  }
}
