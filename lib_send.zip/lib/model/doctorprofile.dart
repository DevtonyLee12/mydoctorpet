import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import '../ui/review_page.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DoctorProfile {
  late String doctorid;
  late String name;
  late String profileImage;
  late String hospital;
  late String medicalSubject;
  late List<Memo> reviewList; //의사에 할당된 리뷰 리스트
  late double ratingInNaver;
  late double ratingViaReviewExpertise;
  late double ratingViaReviewKind;
  late DocumentReference? reference;

  DoctorProfile(
      {required this.doctorid,
      required this.name,
      required this.profileImage,
      required this.hospital,
      required this.medicalSubject,
      required this.reviewList,
      required this.ratingInNaver,
      required this.ratingViaReviewExpertise,
      required this.ratingViaReviewKind,
      this.reference});

  // final doctor = DoctorProfile(
  //     name: "김지헌",
  //     profileImage: "http://24onamc.com/data/medical/1_t",
  //     medicalSubject: "외과",
  //     reviewList: [],
  //     hospital: "24시 잠실 on 동물병원",
  //     ratingInNaver: 4.4,
  //     ratingViaReviewExpertise: 3.5,
  //     ratingViaReviewKind: 3.5);

// final doctorRef = FirebaseFirestore.instance("doters")
//     .withConverter(
//       fromFirestore: DoctorProfile().fromFirestore,
//       toFirestore: (DoctorProfile doctor, options) => doctor.toFirestore(),
//     )
//     .doc("doctor1");
//       await docRef.set(doctor);

  DoctorProfile.fromJson(
      Map<String, dynamic> json, this.doctorid, this.reference) {
    doctorid = json['doctorid'] ?? "";
    name = json['name'] ?? "";
    profileImage = json['profileImage'] ?? "";
    medicalSubject = json['medicalSubject'] ?? "";
    if (json['Memo'] != null) {
      reviewList = <Memo>[];
      json['Memo'].forEach((v) {
        reviewList.add(Memo.fromJson(v));
      });
    }

    // reviewList = json['reviewList'] ?? [];//예시 작성해보
    hospital = json['hospital'] ?? "";
    ratingInNaver = json['ratingInNaver'] ?? 4.5;
    ratingViaReviewExpertise = json['ratingViaReviewExpertise'] ?? 4.5;
    ratingViaReviewKind = json['ratingViaReviewKind'] ?? 3.5;
  }

// DoctorProfile.fromSnapshot(documentSnapshot<Map<String, dynamic>> snapshot)
//   : this.fromJson(snapshot.data()!, snapshot.id, snapshot.reference);//-> 무슨 뜻인지 모름 그냥 적음

  DoctorProfile.fromQuerySnapshot(
      QueryDocumentSnapshot<Map<String, dynamic>> snapshot)
      : this.fromJson(snapshot.data(), snapshot.id, snapshot.reference);

  DoctorProfile.fromSnapshot(DocumentSnapshot<Map<String, dynamic>> snapshot)
      : this.fromJson(snapshot.data()!, snapshot.id, snapshot.reference);

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['doctorid'] = doctorid;
    map['name'] = name;
    map['profileImage'] = profileImage;
    map['profileImage'] = profileImage;
    map['medicalSubject'] = medicalSubject;
    map['reviewList'] = reviewList;
    map['hospital'] = hospital;
    map['ratingViaReviewExpertise'] = ratingViaReviewExpertise;
    map['ratingViaReviewKind'] = ratingViaReviewKind;

    return map;
  }
}

// static DoctorProfile fromsnapshot(
//     DocumentSnapshot<Map<String, dynamic>> documentSnapshot) {}

// final doctor = DoctorProfile(
//     name: '김지헌',
//     profileImage: 'http://24onamc.com/data/medical/1_t',
//     hospital: "24시 잠실 on 동물병원",
//     medicalSubject: "외과",
//     reviewList: [],
//     ratingInNaver: 4.4,
//     ratingViaReviewExpertise: 3.5,
//     ratingViaReviewKind: 3.5);

// final doctorRef = FirebaseFirestore.instance
//     .collection('doctors')
//     .withConverter<DoctorProfile>(
//       fromFirestore: (snapshots, _) =>
//           DoctorProfile.fromJson(snapshots.data()!),
//       toFirestore: (doctor, _) => doctor.toJson(),
//     );

// Future<void> main() async {
//   // Writes now take a Model as parameter instead of a Map
//   await doctorRef.add(doctor);
// }

//   factory DoctorProfile.fromFirestore(
//     DocumentSnapshot<Map<String, dynamic>> snapshot,
//     SnapshotOptions? options,
//   ) {
//     final data = snapshot.data();
//     return DoctorProfile(
//       name: data?['name'],
//       // profileImage: data?['profileImage'] != null
//       //     ? data?['profileImage'].cast<String>()
//       //     : [],
//       medicalSubject: data?['medicalSubject'],
//       reviewList: data?['reviewList'],
//       hospital: data?['hospitalList'],
//       ratingInNaver: data?['ratingInnaver'],
//       ratingViaReviewExpertise: data?['ratingViaReviewExpertise'],
//       ratingViaReviewKind: data?['ratingViaReviewKind'],
//     );
//   }
//   Map<String, dynamic> toFirestore() {
//     return {
//       if (name != null) "name": name,
//       if (profileImage != null) "profileImage": profileImage,
//       if (medicalSubject != null) "medicalSubject": medicalSubject,
//       if (reviewList != null) "reviewList": reviewList,
//       if (hospital != null) "hospital": hospital,
//       if (ratingInNaver != null) "ratingInNaver": ratingInNaver,
//       if (ratingViaReviewExpertise != null)
//         "ratingViaReviewExpertise": ratingViaReviewExpertise,
//       if (ratingViaReviewKind != null)
//         "ratingViaReviewKind": ratingViaReviewKind,
//     };
//   }
// // }
// final doctorRef = FirebaseFirestore.instance("doters")
// //     .withConverter(
// //       fromFirestore: DoctorProfile().fromFirestore,
// //       toFirestore: (DoctorProfile doctor, options) => doctor.toFirestore(),
// //     )
// //     .doc("doctor1");
// //       await docRef.set(doctor);

class HospitalInfo {
  String? phoneNumber;
  String? operationTimeforWeekday;
  String? operationTImeforWeekend;
  String? location;

  HospitalInfo(
      {this.phoneNumber,
      this.operationTimeforWeekday,
      this.operationTImeforWeekend,
      this.location});

  HospitalInfo.fromJson(Map<String, dynamic> json) {
    phoneNumber = json['phoneNumber'] ?? "";
    operationTimeforWeekday = json['operationTimeforWeekday'] ?? "";
    operationTImeforWeekend = json['operationTImeforWeekend'] ?? "";
    location = json['location'] ?? "";
  }

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['phoneNumber'] = phoneNumber;
    map['operationTimeforWeekday'] = operationTimeforWeekday;
    map['operationTImeforWeekend'] = operationTImeforWeekend;
    map[' location'] = location;

    return map;
  }
}
