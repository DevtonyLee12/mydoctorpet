// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';

// final Stream<QuerySnapshot> _memoStream = FirebaseFirestore.instance
//     .collection('memos')
//     .orderBy('wdate', descending: true)
//     .snapshots();

// class FireModel {
//   FireModel({
//     this.content,
//     this.wdate,
//   });
// }
