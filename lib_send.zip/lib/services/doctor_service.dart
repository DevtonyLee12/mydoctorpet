import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:mypet_doctor/model/doctorprofile.dart';
import 'package:mypet_doctor/ui/doc_list/doc_list_page.dart';

class DoctorProfileService {
  static final DoctorProfileService _doctorService =
      DoctorProfileService._internal();

  factory DoctorProfileService({Key? key}) => _doctorService;
  DoctorProfileService._internal();

  Future createNewDoctor(Map<String, dynamic> json, String doctorid) async {
    DocumentReference<Map<String, dynamic>> documentReference =
        FirebaseFirestore.instance.collection('doctorprofile').doc(doctorid);
    final DocumentSnapshot documentSnapshot = await documentReference.get();

    if (!documentSnapshot.exists) {
      await documentReference.set(json);
    }
  }

  Future<DoctorProfile> getDoctor(String doctorid) async {
    DocumentReference<Map<String, dynamic>> documentReference =
        FirebaseFirestore.instance.collection('doctorprofile').doc(doctorid);

    final DocumentSnapshot<Map<String, dynamic>> documentSnapshot =
        await documentReference.get();

    DoctorProfile doctorProfile = DoctorProfile.fromSnapshot(documentSnapshot);

    return doctorProfile;
  }

  Future<List<DoctorProfile>> getDotors() async {
    CollectionReference<Map<String, dynamic>> collectionReference =
        FirebaseFirestore.instance.collection('doctorprofile');
    QuerySnapshot<Map<String, dynamic>> snapshots =
        await collectionReference.get();

    List<DoctorProfile> doctorInformation = [];

    for (int i = 0; i < snapshots.size; i++) {
      DoctorProfile doctorProfile =
          DoctorProfile.fromQuerySnapshot(snapshots.docs[i]);
      doctorInformation.add(doctorProfile);
    }
    print(doctorInformation);
    return doctorInformation;
  }
}


  // final doctorCollection =
  //     FirebaseFirestore.instance.collection('doctorprofile');

  // static List<String> doctorIDs = [];

  // static Future getDoctorIDs() async {
  //   await FirebaseFirestore.instance
  //       .collection('doctorprofile')
  //       .get()
  //       .then((snapshot) => snapshot.docs.forEach((Document) {
  //             print(Document.reference);
  //             doctorIDs.add(Document.reference.id);
  //           }));
  // }

  // Future<QuerySnapshot> read(String doctorIDs) async {
  //   // 내 bucketList 가져오기
  //   return doctorCollection.where('doctorid', isEqualTo: doctorIDs).get();
  // }




















// class BucketService extends ChangeNotifier {
//   final bucketCollection = FirebaseFirestore.instance.collection('bucket');


//  Future<String> getDoctorInfo() async {
//     await Future.delayed(const Duration(milliseconds: 2000), () {});
//     return 'test';
//   }


//   GetDoctorInfo({required this.documentId});
//   @override
//   Widget build(BuildContext context) {
//     CollectionReference doctorprofile =
//         FirebaseFirestore.instance.collection('doctorprofile');
//     return FutureBuilder<DocumentSnapshot>(
//         future: doctorprofile.doc(documentId).get(),
//         builder: ((context, snapshot) {
//           if (snapshot.connectionState == ConnectionState.done) {
//             Map<String, dynamic> data =
//                 snapshot.data!.data() as Map<String, dynamic>;
//             return Text(data['name']);
//           }
//           return Text('loading...');
//         }));
//   }
// }






















// import 'dart:html';

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_storage/firebase_storage.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:mypet_doctor/model/doctorprofile.dart';

// class DoctorService {
//   void DoctorProfileRead() {
//     FirebaseFirestore.instance.collection('dotors').snapshots().map(
//         (snapshot) =>
//             snapshot.docs.map((doc) => DoctorProfile.fromJson(doc.data())
//                 // .toList()
//                 ));
//   }
// }

// List<String> doctorIDs = [];

// Future getDoctorIDs() async {
//   await FirebaseFirestore.instance
//       .collection('doctors')
//       .get()
//       .then((snapshot) => snapshot.docs.forEach((Document) {
//             print(Document.reference);
//             doctorIDs.add(Document.reference.id);
//           }));
// }
